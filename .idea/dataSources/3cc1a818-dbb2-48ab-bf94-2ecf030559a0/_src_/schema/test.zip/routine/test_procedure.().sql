CREATE PROCEDURE test.test_procedure()
  BEGIN
	DECLARE exit handler for sqlexception
		BEGIN
			-- ERROR
		update test.test_table set roll='123' where id=3;
		ROLLBACK;
	END;
	start transaction ;
		insert into test.test_table values(1, 1);
		insert into test.test_table values(2, 2);
		insert into test.test_table values(3, 12);
		commit;
        savepoint A;
		update test.test_table set roll='shivam' where id=3;
        rollback to A;
        release savepoint A;
END;
